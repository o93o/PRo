
import { useState } from "react";
import { api } from "../api";

export default function Register() {
  const [email,setEmail]=useState("");
  const [name,setName]=useState("");
  const [password,setPassword]=useState("");

  const submit = async () => {
    await api.post("/auth/register",{email,name,password});
    location.href="/login";
  };

  return (
    <div className="center">
      <div className="card">
        <h2>Register</h2>
        <input placeholder="Email" onChange={e=>setEmail(e.target.value)} />
        <input placeholder="Name" onChange={e=>setName(e.target.value)} />
        <input type="password" placeholder="Password" onChange={e=>setPassword(e.target.value)} />
        <button onClick={submit}>Create</button>
      </div>
    </div>
  );
}
