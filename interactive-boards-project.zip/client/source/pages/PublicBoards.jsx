
export default function PublicBoards() {
  return (
    <div className="page">
      <h1>Public Boards</h1>
      <p>Boards list will be here</p>
    </div>
  );
}
