
import { useEffect, useState } from "react";
import Canvas from "../components/Canvas";

export default function Board() {
  const [ws,setWs]=useState(null);

  useEffect(()=>{
    const s=new WebSocket("ws://localhost:3000");
    setWs(s);
  },[]);

  return (
    <div className="page">
      <h1>Board</h1>
      <Canvas ws={ws} />
    </div>
  );
}
