
import { useEffect, useRef } from "react";
import { fabric } from "fabric";

export default function Canvas({ ws }) {
  const ref = useRef();

  useEffect(() => {
    const canvas = new fabric.Canvas(ref.current, {
      width: 1600,
      height: 900,
      backgroundColor: "#ffffff"
    });

    const rect = new fabric.Rect({
      width: 120,
      height: 80,
      fill: "#4f46e5",
      left: 100,
      top: 100
    });

    canvas.add(rect);

    canvas.on("object:modified", e => {
      ws?.send(JSON.stringify({
        type: "update",
        object: e.target.toJSON()
      }));
    });

  }, []);

  return <canvas ref={ref} className="boardCanvas" />;
}
