
import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import authRoutes from "./routes/auth.js";
import boardRoutes from "./routes/boards.js";
import { initWS } from "./ws.js";

const app = express();
app.use(cors());
app.use(express.json());

app.use("/auth", authRoutes);
app.use("/boards", boardRoutes);

mongoose.connect("mongodb://127.0.0.1/boards");

const server = app.listen(3000, () => console.log("Server started 3000"));
initWS(server);
