
import { WebSocketServer } from "ws";
const rooms = {};

export function initWS(server) {
  const wss = new WebSocketServer({ server });

  wss.on("connection", ws => {
    ws.on("message", raw => {
      const msg = JSON.parse(raw);
      const board = msg.board || "main";

      if (!rooms[board]) rooms[board] = [];
      if (!rooms[board].includes(ws)) rooms[board].push(ws);

      rooms[board].forEach(c => {
        if (c !== ws) c.send(raw);
      });
    });
  });
}
