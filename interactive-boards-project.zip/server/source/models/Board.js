
import mongoose from "mongoose";

export default mongoose.model("Board", {
  title: String,
  ownerId: String,
  editors: [String],
  isPublic: Boolean,
  publicHash: String,
  likes: { type: Number, default: 0 }
});
