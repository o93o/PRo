
import mongoose from "mongoose";

export default mongoose.model("User", {
  email: String,
  name: String,
  password: String
});
