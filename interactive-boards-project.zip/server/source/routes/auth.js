
import express from "express";
import bcrypt from "bcrypt";
import jwt from "jsonwebtoken";
import User from "../models/User.js";

const r = express.Router();

r.post("/register", async (req, res) => {
  const { email, name, password } = req.body;
  if (!/^[A-Za-z]+$/.test(name)) return res.status(400).send("Name invalid");
  if (password.length < 8) return res.status(400).send("Password short");

  const hash = await bcrypt.hash(password, 10);
  await User.create({ email, name, password: hash });
  res.sendStatus(200);
});

r.post("/login", async (req, res) => {
  const { email, password } = req.body;
  const u = await User.findOne({ email });
  if (!u) return res.status(400).send("No user");

  const ok = await bcrypt.compare(password, u.password);
  if (!ok) return res.status(400).send("Wrong pass");

  const token = jwt.sign({ id: u._id, name: u.name }, "secret");
  res.json({ token });
});

export default r;
