
import express from "express";
import auth from "../middleware/auth.js";
import Board from "../models/Board.js";
import { v4 as uuid } from "uuid";

const r = express.Router();

r.post("/", auth, async (req, res) => {
  const b = await Board.create({
    title: req.body.title,
    ownerId: req.user.id,
    editors: [req.user.id]
  });
  res.json(b);
});

r.get("/public", async (req, res) => {
  const boards = await Board.find({ isPublic: true });
  res.json(boards);
});

r.post("/:id/public", auth, async (req, res) => {
  const b = await Board.findById(req.params.id);
  b.isPublic = true;
  b.publicHash = uuid();
  await b.save();
  res.json({ hash: b.publicHash });
});

r.post("/:id/like", auth, async (req, res) => {
  const b = await Board.findById(req.params.id);
  b.likes++;
  await b.save();
  res.sendStatus(200);
});

export default r;
